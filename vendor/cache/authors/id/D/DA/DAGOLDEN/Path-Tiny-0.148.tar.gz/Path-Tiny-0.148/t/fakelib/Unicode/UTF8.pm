package Unicode::UTF8;

0;    # make require fail
