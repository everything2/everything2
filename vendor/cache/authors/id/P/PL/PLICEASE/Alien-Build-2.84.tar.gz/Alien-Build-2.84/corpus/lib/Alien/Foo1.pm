package Alien::Foo1;

use strict;
use warnings;
use parent qw( Alien::Base );

1;
