package Foo::Bar::Baz1;

use strict;
use warnings;

our $VERSION = '1.23';

1;
