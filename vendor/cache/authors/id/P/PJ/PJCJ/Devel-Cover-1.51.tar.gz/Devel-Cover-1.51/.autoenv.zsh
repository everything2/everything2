if [[ $autoenv_event == "enter" ]]; then
  . ./utils/setup
else
fi
