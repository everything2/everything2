# In Memorium

## 1.45

Version 1.45 is dedicated to the memory of Abe Timmerman (abeltje).

A lot of Devel::Cover work in recent years has been completed at Perl QA
Hackathons and Perl Toolchain Summits.  Very often at these events I would sit
next to Abe as he was working on Perl's test smoking infrastructure.

Frequently Abe would be deep into a problem with his headphones on.  And then
occasionally he would lean back in his chair and play a little drum roll.  Then
he might take off his headphones and we'd discuss what we were working on or
maybe some other topic.

Thanks for those good times, Abe.  This release is dedicated to you.
