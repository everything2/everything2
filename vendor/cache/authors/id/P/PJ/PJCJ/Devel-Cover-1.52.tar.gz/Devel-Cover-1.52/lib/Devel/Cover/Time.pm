# Copyright 2001-2026, Paul Johnson (paul@pjcj.net)

# This software is free.  It is licensed under the same terms as Perl itself.

# The latest version of this software should be available from my homepage:
# https://pjcj.net

package Devel::Cover::Time;

use strict;
use warnings;

our $VERSION = '1.52'; # VERSION

use base "Devel::Cover::Criterion";

sub uncoverable { 0 }
sub covered     { ${ $_[0] } }
sub total       { 1 }
sub percentage  { ${ $_[0] } ? 100 : 0 }
sub error       { 0 }

sub calculate_summary {
  my $self = shift;
  my ($db, $file) = @_;

  $db->{summary}{$file}{time}{total} += $$self;
  $db->{summary}{Total}{time}{total} += $$self;
}

sub calculate_percentage {
  my $class = shift;
  my ($db, $s) = @_;
  my $t = $db->{summary}{Total}{time}{total};
  $s->{percentage} = $t ? $s->{total} * 100 / $t : 100;
}

1

__END__

=head1 NAME

Devel::Cover::Time - Code coverage metrics for Perl

=head1 VERSION

version 1.52

=head1 SYNOPSIS

 use Devel::Cover::Time;

=head1 DESCRIPTION

Module for storing time coverage information.

=head1 SEE ALSO

 Devel::Cover::Criterion

=head1 METHODS

=head2 new

 my $db = Devel::Cover::DB->new(db => "my_coverage_db");

Constructs the DB from the specified database.

=head1 LICENCE

Copyright 2001-2026, Paul Johnson (paul@pjcj.net)

This software is free.  It is licensed under the same terms as Perl itself.

The latest version of this software should be available from my homepage:
https://pjcj.net

=cut
