# Copyright 2001-2026, Paul Johnson (paul@pjcj.net)

# This software is free.  It is licensed under the same terms as Perl itself.

# The latest version of this software should be available from my homepage:
# https://pjcj.net

package Devel::Cover::Condition_and_2;

use strict;
use warnings;

our $VERSION = '1.52'; # VERSION

use base "Devel::Cover::Condition";

sub count   { 2 }
sub headers { [qw( l !l )] }

1

__END__

=head1 NAME

Devel::Cover::Condition_and_2 - Code coverage metrics for Perl

=head1 VERSION

version 1.52

=head1 SYNOPSIS

 use Devel::Cover::Condition_and_2;

=head1 DESCRIPTION

Module for storing condition coverage information for and conditions
where the right value is a constant.

=head1 SEE ALSO

 Devel::Cover::Condition

=head1 METHODS

=head1 LICENCE

Copyright 2001-2026, Paul Johnson (paul@pjcj.net)

This software is free.  It is licensed under the same terms as Perl itself.

The latest version of this software should be available from my homepage:
https://pjcj.net

=cut
