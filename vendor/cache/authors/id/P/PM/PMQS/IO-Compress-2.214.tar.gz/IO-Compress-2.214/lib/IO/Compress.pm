package IO::Compress;

our $VERSION = '2.214' ;

=head1 NAME

IO::Compress - read/write compressed data in multiple formats

=head1 DESCRIPTION

This is a stub module. It contains no code.

=head1 AUTHOR

Paul Marquess F<pmqs@cpan.org>.

=head1 COPYRIGHT

Copyright (c) 2011-2024 Paul Marquess. All rights reserved.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.

=cut


1;