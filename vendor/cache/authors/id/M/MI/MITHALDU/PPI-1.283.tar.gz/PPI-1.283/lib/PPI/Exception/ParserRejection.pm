package PPI::Exception::ParserRejection;

use strict;
use PPI::Exception ();

our $VERSION = '1.283';

our @ISA = 'PPI::Exception';

1;
