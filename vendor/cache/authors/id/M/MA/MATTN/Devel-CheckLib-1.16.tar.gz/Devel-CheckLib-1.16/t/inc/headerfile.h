int foo(void);
int libversion(void);

