package MooseClass;

use Moose;

1;
