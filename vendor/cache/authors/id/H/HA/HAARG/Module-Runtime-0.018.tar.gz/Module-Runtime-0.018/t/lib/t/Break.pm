package t::Break;

{ use 5.006; }
use warnings;
use strict;

die "broken";
