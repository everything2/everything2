package LoadFailTest::LoadFailMod;

return 0;
