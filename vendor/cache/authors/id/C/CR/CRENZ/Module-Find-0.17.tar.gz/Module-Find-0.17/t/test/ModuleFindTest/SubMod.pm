package ModuleFindTest::SubMod;

sub theRealDeal {
    return 1;
}

$ModuleFindTest::SubMod::loaded = 1;
