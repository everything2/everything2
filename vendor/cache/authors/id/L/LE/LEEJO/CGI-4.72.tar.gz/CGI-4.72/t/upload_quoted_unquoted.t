#!/usr/local/bin/perl -w

use strict;
use Test::More 'no_plan';
use CGI qw/ :cgi /;
use utf8;

my %myenv;

BEGIN {
    %myenv = (
        'SCRIPT_NAME'       => '/test.cgi',
        'SERVER_NAME'       => 'perl.org',
        'HTTP_CONNECTION'   => 'TE, close',
        'REQUEST_METHOD'    => 'POST',
        'SCRIPT_URI'        => 'http://www.perl.org/test.cgi',
        'CONTENT_LENGTH'    => 3285,
        'SCRIPT_FILENAME'   => '/home/usr/test.cgi',
        'SERVER_SOFTWARE'   => 'Apache/1.3.27 (Unix) ',
        'HTTP_TE'           => 'deflate,gzip;q=0.3',
        'QUERY_STRING'      => '',
        'REMOTE_PORT'       => '1855',
        'HTTP_USER_AGENT'   => 'Mozilla/5.0 (compatible; Konqueror/2.1.1; X11)',
        'SERVER_PORT'       => '80',
        'REMOTE_ADDR'       => '127.0.0.1',
        'CONTENT_TYPE'      => 'multipart/form-data; boundary="----MyGreatBoundary',
        'SERVER_PROTOCOL'   => 'HTTP/1.1',
        'PATH'              => '/usr/local/bin:/usr/bin:/bin',
        'REQUEST_URI'       => '/test.cgi',
        'GATEWAY_INTERFACE' => 'CGI/1.1',
        'SCRIPT_URL'        => '/test.cgi',
        'SERVER_ADDR'       => '127.0.0.1',
        'DOCUMENT_ROOT'     => '/home/develop',
        'HTTP_HOST'         => 'www.perl.org'
    );

    for my $key (keys %myenv) {
        $ENV{$key} = $myenv{$key};
    }
}

END {
    for my $key (keys %myenv) {
        delete $ENV{$key};
    }
}

my $q;

{
    local *STDIN;
    open STDIN, '<t/upload_post_quoted_unquoted.txt'
        or die 'missing test file t/upload_post_quoted_unquoted.txt';
    binmode STDIN;
    $q = CGI->new;
}

note explain $q;

# simple names
is( $q->param('code'),'4019300163786','code' );
is( $q->param('word'),'squeaky','word' );

TODO: {
	# may need to MIME encode the name value in this case
	local $TODO = "->param borked with non-ascii?";
	is( $q->param('éttu'),'oui','éttu' );
};

# hateful names
is( $q->param('why do \"this\"'),'because','quoted with quote' );
is(
	$q->param("hate ()<>@,;:[]?={}\t/\\\""),
	'really hateful',
	'reserved chars',
);

# vim: nospell
