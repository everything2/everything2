#! perl

use strict;
no warnings;
use Test::More $] < 5.008 ? (tests => 39) : (tests => 713);

use Cpanel::JSON::XS;

sub splitter {
   my ($coder, $text) = @_;

   for (0 .. length $text) {
      my $a = substr $text, 0, $_;
      my $b = substr $text, $_;

      $coder->incr_parse ($a);
      $coder->incr_parse ($b);

      my $data = $coder->incr_parse;
      ok ($data);
      ok ($coder->encode ($data) eq $coder->encode ($coder->decode ($text)), "data");
      ok ($coder->incr_text =~ /^\s*$/, "tailws");
   }
}

if ($] >= 5.008) {
  splitter +Cpanel::JSON::XS->new->canonical   , '  ["x\\"","\\u1000\\\\n\\nx",1,{"\\\\" :5 , "": "x"}]';
  splitter +Cpanel::JSON::XS->new->canonical   , '[ "x\\"","\\u1000\\\\n\\nx" , 1,{"\\\\ " :5 , "": " x"} ] ';
}
splitter +Cpanel::JSON::XS->new->allow_nonref->canonical, '"test"';
splitter +Cpanel::JSON::XS->new->allow_nonref->canonical, ' "5" ';

diag "skip lvalue incr_text for 5.6" if $] < 5.008;
exit if $] < 5.008;

{
   my $text = '[5],{"":1} , [ 1,2, 3], {"3":null}';
   my $coder = new Cpanel::JSON::XS;
   for (0 .. length $text) {
      my $a = substr $text, 0, $_;
      my $b = substr $text, $_;

      $coder->incr_parse ($a);
      $coder->incr_parse ($b);

      my $j1 = $coder->incr_parse; ok ($coder->incr_text =~ s/^\s*,//, "cskip1");
      my $j2 = $coder->incr_parse; ok ($coder->incr_text =~ s/^\s*,//, "cskip2");
      my $j3 = $coder->incr_parse; ok ($coder->incr_text =~ s/^\s*,//, "cskip3");
      my $j4 = $coder->incr_parse; ok ($coder->incr_text !~ s/^\s*,//, "cskip4");
      my $j5 = $coder->incr_parse; ok ($coder->incr_text !~ s/^\s*,//, "cskip5");

      ok ('[5]' eq encode_json ($j1), "cjson1");
      ok ('{"":1}' eq encode_json ($j2), "cjson2");
      ok ('[1,2,3]' eq encode_json ($j3), "cjson3");
      ok ('{"3":null}' eq encode_json ($j4), "cjson4");
      ok (!defined $j5, "cjson5");
   }
}

{
   my $text = '[x][5]';
   my $coder = new Cpanel::JSON::XS;
   $coder->incr_parse ($text);
   ok (!eval { $coder->incr_parse }, "sparse1");
   ok (!eval { $coder->incr_parse }, "sparse2");
   $coder->incr_skip;
   ok ('[5]' eq $coder->encode (scalar $coder->incr_parse), "sparse3");
}

{
   my $coder = Cpanel::JSON::XS->new->max_size (5);
   ok (!$coder->incr_parse ("[    "), "incsize1");
   eval { !$coder->incr_parse ("]  ") }; ok ($@ =~ /6 bytes/, "incsize2 $@");
}

{
   my $coder = Cpanel::JSON::XS->new->max_depth (3);
   ok (!$coder->incr_parse ("[[["), "incdepth1");
   eval { !$coder->incr_parse (" [] ") }; ok ($@ =~ /maximum nesting/, "incdepth2 $@");
}

# contributed by yuval kogman, reformatted to fit style
{
   my $coder = Cpanel::JSON::XS->new;
   
   my $res = eval { $coder->incr_parse("]") };
   my $e = $@; # test more clobbers $@, we need it twice
   
   ok (!$res, "unbalanced bracket");
   ok ($e, "got error");
   like ($e, qr/malformed/, "malformed json string error");
   
   $coder->incr_skip;
   
   is_deeply (eval { $coder->incr_parse("[42]") }, [42], "valid data after incr_skip");
}

# GH 123
{
   my $text = '[1][5]';
   my $coder = new Cpanel::JSON::XS;
   $coder->incr_parse ($text);
   $coder->incr_text;
   is ($@, '', 'incr_text allowed after incr_parse init');
   ok (eval { $coder->incr_parse }, "incr_parse2");
   # here incr_text might be at incr_pos 3 or chopped
   $coder->incr_reset;
   $coder->incr_text;
   is ($@, '', 'incr_text is allowed after incr_reset');
   is (encode_json($coder->incr_parse($text)), '[1]', "incr_parse1");
   is (encode_json($coder->incr_parse), '[5]', "incr_parse2");
}

# allow_singlequote: } inside single-quoted string must not close the object
{
   my $coder = Cpanel::JSON::XS->new->allow_singlequote(1);

   # feed partial input: the } is inside the single-quoted value, must not trigger done
   ok (!defined $coder->incr_parse("{'a':'}'"), "sqstr-incr: } inside single-quote does not close object");

   # complete the object
   my $r = $coder->incr_parse("}");
   ok (defined $r, "sqstr-incr: object completes after closing brace");
   is_deeply ($r, {a => "}"}, "sqstr-incr: decoded value correct");
}

# allow_singlequote: chunked streaming with structural chars inside single-quoted string
{
   my $coder = Cpanel::JSON::XS->new->allow_singlequote(1);

   # feed one byte at a time to exercise every state transition
   my $json = "{'x':'}[{'}";
   my $r;
   for my $ch (split //, $json) {
      $r = $coder->incr_parse($ch);
   }
   ok (defined $r, "sqstr-incr chunked: defined result");
   is_deeply ($r, {x => "}[{"}, "sqstr-incr chunked: decoded value correct");
}

# allow_singlequote: backslash inside single-quoted string does not cause premature end
{
   my $coder = Cpanel::JSON::XS->new->allow_singlequote(1);

   ok (!defined $coder->incr_parse("{'k':'a\\'"), "sqstr-incr BS: partial with escaped quote waits");
   my $r = $coder->incr_parse("b'}");
   ok (defined $r, "sqstr-incr BS: completes after full input");
   is_deeply ($r, {k => "a'b"}, "sqstr-incr BS: decoded value correct");
}

# allow_singlequote: single-quoted array element containing structural chars
{
   my $coder = Cpanel::JSON::XS->new->allow_singlequote(1);
   my $r;
   $r = $coder->incr_parse("['he");
   ok (!defined $r, "sqstr-incr array: partial waits");
   $r = $coder->incr_parse("llo}']");
   ok (defined $r, "sqstr-incr array: completes");
   is_deeply ($r, ['hello}'], "sqstr-incr array: value correct");
}
