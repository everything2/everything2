package EditorJunk::Foo;


use strict;


1;


