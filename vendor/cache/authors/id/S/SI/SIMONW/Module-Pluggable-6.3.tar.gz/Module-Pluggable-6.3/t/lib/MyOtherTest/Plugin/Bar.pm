package MyOtherTest::Plugin::Bar;
use strict;
1;


