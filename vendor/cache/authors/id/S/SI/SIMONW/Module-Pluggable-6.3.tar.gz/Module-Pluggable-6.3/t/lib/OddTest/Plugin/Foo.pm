package OddFiles/Plugin/Foo.pm

sub new {}

1;
