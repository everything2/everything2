## YAML Test Data for Schemas (YAML 1.1, YAML 1.2 Core, JSON, Failsafe)

[HTML](https://perlpunk.github.io/yaml-test-schema/)
