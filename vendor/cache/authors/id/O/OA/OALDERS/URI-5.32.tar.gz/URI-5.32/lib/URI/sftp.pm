package URI::sftp;

use strict;
use warnings;

our $VERSION = '5.32';

use parent 'URI::ssh';

1;
