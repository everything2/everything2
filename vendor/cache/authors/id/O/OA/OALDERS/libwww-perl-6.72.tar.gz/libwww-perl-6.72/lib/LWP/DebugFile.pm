package LWP::DebugFile;

our $VERSION = '6.72';

# legacy stub

1;
