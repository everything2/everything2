package LWP::DebugFile;

our $VERSION = '6.79';

# legacy stub

1;
