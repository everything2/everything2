package Overloading::RoleWithoutOverloads;

use Moose::Role;

1;
