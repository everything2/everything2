package Moose::Meta::Attribute::Custom::Foo;

use Moose::Role;

1;
